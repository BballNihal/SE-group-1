/*get all order ID's belonging to one member
GET order/list
format:
{
   "ABC":{
    "memberID":"M1234567890123456"
   }
}
*/