/*get all order details belonging to one member
(products ordered, order date, price, payment info)
(similar to list orders)
GET order/details
format:
{
   "ABC":{
    "memberID":"M1234567890123456"
   }
}
*/