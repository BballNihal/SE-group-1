/*cancel an order by ID (remove it)
POST order/cancel
format:
{
   "ABC":{
    "orderID":"O1234567890"
   }
}
*/